import {
  require_react_dom
} from "./chunk-EZWSRKYN.js";
import "./chunk-GFWMZNU4.js";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
