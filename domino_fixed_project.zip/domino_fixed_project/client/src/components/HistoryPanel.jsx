import React from 'react'
export default function HistoryPanel({history}){
  return <div>
    <div className="section-title">Історія (поточна сесія)</div>
    <div className="small">Події добору/ходу/пасу фіксуються у журналі сервісу (демо-версія).</div>
  </div>
}
