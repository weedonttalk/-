export const SIDES = ['L','R','U','D']
